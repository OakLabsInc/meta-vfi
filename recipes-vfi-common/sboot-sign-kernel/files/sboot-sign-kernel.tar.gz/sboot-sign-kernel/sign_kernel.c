#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <errno.h>

#include "sign_kernel.h"
#include "aes256.h"

#define AES_BLOCK_SIZE  16
//#define DEBUG

static 	uint8_t key[32];

void aes_encrypt_data(aes256_context *ctx, uint8_t *data, int num)
{
	int num_enc_bytes = 0;
	aes256_init(ctx, key);
	while(num_enc_bytes < num)
	{
		aes256_encrypt_ecb(ctx, data);
		num_enc_bytes += AES_BLOCK_SIZE;
		data += AES_BLOCK_SIZE;
		/* Padding has to be done for the last frame */
		if((num - num_enc_bytes) < AES_BLOCK_SIZE)	{
			/*Padd the remaining clock*/
		}
	}
}

#ifdef TEST_DECRYPT
int	aes_decrypt_data(aes256_context *ctx, uint8_t *data, int num)
{
	int num_enc_bytes = 0;
	aes256_init(ctx, key);
	while(num_enc_bytes < num)
	{
		aes256_decrypt_ecb(ctx, data);
		num_enc_bytes += AES_BLOCK_SIZE;
		data += AES_BLOCK_SIZE;
		/* Padding has to be done for the last frame */
		if((num - num_enc_bytes) < AES_BLOCK_SIZE)	{
			/*Padd the remaining clock*/
		}
	}
}
#endif

int main (int argc, char *argv[])
{
	aes256_context ctx;
    int i,j,k;
    int no_of_files;
    unsigned char pcr[64];
    unsigned char pcr2[64];
    uint8_t hash_result_sha256[32];
	unsigned char hash[2][64]; /* [0] = Passphrase, [1] = kernel */
    sha256_ctx my_sha256;
	int fd = -1, fd_wr = -1;
	char *buf = NULL;
	unsigned char buf_hash[HASH_LENGTH];
//	uint8_t char_hash256_result[CHAR_HASH_LENGTH];
//	uint8_t tmp[64];
//	char lookup_table[16] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
	char *file_hash = NULL;
	char *hbuf = NULL;
	int ret;
	int stErr = 0;

	if(argc < 2 || !strcmp("--help", argv[1]))	{
		printf("Usage() \n");
		printf("%s <kernel-image> </path/for/chacksumfile>\n", argv[0]);
		printf("For ex : %s /boot/bzImage /etc/signed-kernel-checksum\n", argv[0]);
		exit(1);
	}
	
	if(argv[2] != NULL) {
		file_hash = (char *)malloc(strlen(argv[2])+1);		// +1 for NULL
		memset(file_hash, 0, strlen(argv[2])+1);
		strcpy(file_hash, argv[2]);
	}
	else {
		file_hash = (char *)malloc(strlen(FILE_HASH)+1);	// +1 for NULL
		memset(file_hash, 0, strlen(FILE_HASH)+1);
		strcpy(file_hash, FILE_HASH);
	}
	
	if (remove(file_hash) < 0)	{
		hbuf = (char *)malloc(strlen(file_hash) + 20);
		sprintf(hbuf, "rm -f %s", file_hash);
		ret = system(hbuf);	
		if (!(WIFEXITED(ret) && (WEXITSTATUS(ret) == 0))) {
			printf("sboot-signer : cannot delete file %s\n", file_hash);
			perror("sboot-signer : File could not delete\n");
			stErr = 1;
			goto free_resource_file_hash;
		}
	}
#ifdef DEBUG
	int len = strlen(file_hash);
	for(i=0; i<len; i++)
		printf("%c", file_hash[i]);
#endif
	 	
	if((fd_wr = open(file_hash, O_CREAT | O_RDWR, 0666)) == -1)	{
		perror("sboot-signer : Error Opening File : \n");
		stErr = 1;
		goto free_resource_file_hash;
	}
	
	
	if((fd = open(FILE_TMP, O_CREAT | O_RDWR, 0666)) == -1)	{
		perror("sboot-signer : Cannot  Open a file\n");
		stErr = 1;
		goto free_resource_file_hash;
	}

	buf = (char *)malloc(strlen(FILE_TMP) + strlen(argv[1]) + 30);
	sprintf(buf, "sha256sum %s > %s", argv[1], FILE_TMP);
#ifdef DEBUG
	printf("sboot-signer :sha256 sum buffer value = %s\n", buf);
#endif
	ret = system(buf);	
	if (!(WIFEXITED(ret) && (WEXITSTATUS(ret) == 0))) {
		perror("sboot-signer : Error executing command \n");
		stErr = 1;
		goto free_resource_buf;
	}

	if((ret = read(fd, buf_hash, HASH_LENGTH)) < 0)	{
		perror("sboot-signer : Error reading file\n");
		stErr = 1;
		goto free_resource_buf;
	}

	/* Passphrase and Kernel */
	memcpy(hash[0], PASSPHRASE, HASH_LENGTH);
	memcpy(hash[1], buf_hash, HASH_LENGTH);
	k=0;
	no_of_files = 2;

#ifdef DEBUG
	printf("Testing PCR value: ");
#endif
for(j=0; j<no_of_files; j++)	
{
	for (i=0; i<64; i++)	
	{
	    switch(hash[j][i])
	    {
		case '0': pcr2[i]=0; break;
		case '1': pcr2[i]=1; break;
		case '2': pcr2[i]=2; break;
		case '3': pcr2[i]=3; break;
		case '4': pcr2[i]=4; break;
		case '5': pcr2[i]=5; break;
		case '6': pcr2[i]=6; break;
		case '7': pcr2[i]=7; break;
		case '8': pcr2[i]=8; break;
		case '9': pcr2[i]=9; break;
		case 'a': pcr2[i]=0xa; break;
		case 'b': pcr2[i]=0xb; break;
		case 'c': pcr2[i]=0xc; break;
		case 'd': pcr2[i]=0xd; break;
		case 'e': pcr2[i]=0xe; break;
		case 'f': pcr2[i]=0xf; break;
		default: printf("Failure, please give correct 20 byte hex string!\n"); return -1;
	    }
	}

#ifdef DEBUG
	printf("OK\nSetting PCR-Register %d with index %d to ", j, k);
#endif
	for (i=0; i<32; i++)
	{
	    pcr[k+i] = pcr2[2*i]<<4 | pcr2[(2*i)+1];
#ifdef DEBUG
	    printf("%02x",pcr[k+i]);
#endif
	}

	k = i; /* Save Index or Update the value of next starting location*/
#ifdef DEBUG
	printf("\n");
#endif
    
}

#ifdef DEBUG
	printf("PCR values\n");
	for (i=0; i<64; i++)	
		printf("%x ",pcr[i]);
#endif

	sha256_init(&my_sha256);
	sha256_update(&my_sha256, pcr, 64);
	sha256_final(&my_sha256, hash_result_sha256);	

#ifdef DEBUG
	printf("Provisional result PCR: \n");
	for (i=0; i<32; i++)
    	    printf("%02x ",hash_result_sha256[i]);
#endif
    	   
   	aes_encrypt_data(&ctx, hash_result_sha256, 32);
   	
#ifdef DEBUG
	printf("Encrypted result PCR: \n");
	for (i=0; i<32; i++)
    	    printf("%02x ",hash_result_sha256[i]);
#endif    	        

	write(fd_wr, hash_result_sha256, 32);

#ifdef TEST_DECRYPT    	    
    aes_decrypt_data(&ctx, hash_result_sha256, 32);
	printf("Decrypted result PCR: \n");
	for (i=0; i<32; i++)
    	    printf("%02x",hash_result_sha256[i]);
#endif

free_resource_buf:
#ifdef DEBUG
	printf("Freeing Resource\n");
#endif
					if(buf != NULL)
						free(buf);
					
free_resource_file_hash:
					if (fd != -1)
						close(fd);
					if (fd_wr != -1)
						close(fd_wr);
					if (file_hash != NULL)
						free(file_hash);
					if (hbuf != NULL)
						free(hbuf);

if (remove(FILE_TMP) < 0)	{
	perror("sboot-signer : remove temp file error, Remove the fileManually \n");
	stErr = 1;
}

	if (stErr)	{
		printf("Error : sboot-signer : kernel checksum not calculated. check error logs for details\n");
		exit(1);
	}
	
	    
    return 0;
}
