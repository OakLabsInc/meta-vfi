//#############################################################################
//#
//#   (C) COPYRIGHT 2003 by VeriFone, Inc. All rights reserved.
//#
//#   FILE NAME: poke.c
//#   MODULE DESC: 
//#   COMPONENT OF: Topaz
//#   AUTHOR(S):  Tom Parra, Venko Baksa
//#   FUNCTION:
//# 
//#   MODIFICATION HISTORY:
//# 
//#   DATE         DESCRIPTION          	INITIALS
//#   -----------  -----------          	--------
//#   26-Mar-2003   Creation             	TP
//#   07-May-2012   Check for iopl error	VB
//#
//#############################################################################

//#############################################################################
//#
//# Place #include files required to compile this source file here.
//#
//#############################################################################

#include <stdio.h>
#include <stdlib.h>
#include <sys/io.h>
#include <errno.h>

//#############################################################################
//#
//# Define global variables that will be used by both this source file
//# and by other source files here.
//#
//#############################################################################

//#############################################################################
//#
//# Place #define constants and macros that will be used only by this
//# source file here.
//#
//#############################################################################

//#############################################################################
//#
//# Place typedefs, structs, unions, and enums that will be used only
//# by this source file here.
//#
//#############################################################################

//#############################################################################
//#
//# Place static variables that will be used only by this file here.
//#
//#############################################################################

//#############################################################################
//#
//# Place function prototypes that will be used only by this file here.
//# This section need only include "forward referenced" functions.
//#
//#############################################################################

//#############################################################################
//#
//# Place function bodies here.
//#
//#############################################################################

//-----------------------------------------------------------------------------
//
//
//
//-----------------------------------------------------------------------------
int main( int argc, char *argv[] )
{
   unsigned int uiPortAddr;
   unsigned int uiValue;
   int iSize = 2;
   int rc;
   int i;

   if ( argc < 3 )
   {
      printf( "Usage is:\n%s <port> <value> [size]\n\n", argv[0] );
   }
   else
   {
      uiPortAddr = (unsigned int) strtol( argv[ 1 ], NULL, 0 );

	for (i = 0; i < strlen(argv[2])-2; i++) {
		if (argv[2][0] != '0' || toupper(argv[2][1]) != 'X'
		   || !(isxdigit(argv[2][2+i]))) { 
			printf("Invalid hex number. Should be 0xhex_num format\n");
			return -1;
		}
	}
		
      uiValue = (unsigned int) strtol( argv[ 2 ], NULL, 0 );

      if ( argc > 3 )
      {
         iSize = (unsigned int) strtol( argv[ 3 ], NULL, 0 );
      }

	if(strlen(argv[2]) <= 2 || !uiPortAddr || !iSize)
		exit (-1);

      rc = iopl( 3 );
      if (rc < 0)
      {
	  printf( "iopl(3) failed: errno = %d\n\n", errno);
	  return (-errno);
      }

      if ( iSize == 1 )
      {
         outb( (unsigned char) (uiValue & 0x0FF), uiPortAddr );
      }
      else
      {
         outw( (unsigned short) (uiValue & 0x0FFFF), uiPortAddr );
      }

      rc = iopl( 0 );
      if (rc < 0)
      {
	  printf( "iopl(0) failed: errno = %d\n\n", errno);
	  return (-errno);
      }
   }

   return 0;
}

//#############################################################################
//#
//# End of file.
//#
//#############################################################################
